document.addEventListener('DOMContentLoaded', function () {
    // Sample data for scores and overs
    const matchData = [
      { score: 120, overs: 15.2, elementId: 'score-1', oversId: 'overs-1' },
      { score: 98, overs: 12.4, elementId: 'score-2', oversId: 'overs-2' },
      { score: 175, overs: 20.0, elementId: 'score-3', oversId: 'overs-3' }
    ];
  
    // Function to simulate score updates
    function updateScores() {
      matchData.forEach((match) => {
        // Increment the score slightly for simulation
        match.score += Math.floor(Math.random() * 5);
        match.overs += 0.1;
  
        // Update the score and overs in the HTML
        document.getElementById(match.elementId).textContent = match.score;
        document.getElementById(match.oversId).textContent = match.overs.toFixed(1);
      });
    }
  
    // Update the scores every 5 seconds
    setInterval(updateScores, 5000);
  });