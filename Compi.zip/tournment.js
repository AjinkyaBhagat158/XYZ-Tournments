document.addEventListener('DOMContentLoaded', function () {
    const registerButtons = document.querySelectorAll('.register-btn');
  
    registerButtons.forEach((button) => {
      button.addEventListener('click', function () {
        alert('You have clicked the Register Now button for ' + this.previousElementSibling.previousElementSibling.textContent);
      });
    });
  });