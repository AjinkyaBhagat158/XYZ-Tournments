

document.addEventListener('DOMContentLoaded', function () {
  console.log("Website is loaded and ready!");

  // Example: Adding an event listener to the "Explore Tournaments" button
  const ctaButton = document.querySelector('.cta-button');
  ctaButton.addEventListener('click', function () {
    alert('Navigating to Tournaments section!');
  });
});